import sys

def check_binary_8bit(value):
    if len(value) != 8 or not set(value) <= {'0', '1'}:
        print("Error: input must be an 8-bit binary number.")
        sys.exit(1)

def main():
    data = input("Enter 8-bit binary data: ")
    check_binary_8bit(data)

    # assign data bits according to their positions in the 12 bits
    d3  = int(data[7])
    d5  = int(data[6])
    d6  = int(data[5])
    d7  = int(data[4])
    d9  = int(data[3])
    d10 = int(data[2])
    d11 = int(data[1])
    d12 = int(data[0])

    # compute parity bits (even parity)
    p1 = d3 ^ d5 ^ d7 ^ d9 ^ d11
    p2 = d3 ^ d6 ^ d7 ^ d10 ^ d11
    p4 = d5 ^ d6 ^ d7 ^ d12
    p8 = d9 ^ d10 ^ d11 ^ d12

    print("p1 =", p1)
    print("p2 =", p2)
    print("d3 =", d3)
    print("p4 =", p4)
    print("d5 =", d5)
    print("d6 =", d6)
    print("d7 =", d7)
    print("p8 =", p8)
    print("d9 =", d9)
    print("d10 =", d10)
    print("d11 =", d11)
    print("d12 =", d12)

    # final order: d12 d11 d10 d9 p8 d7 d6 d5 p4 d3 p2 p1
    hamming_code = (
        str(d12) + str(d11) + str(d10) + str(d9) +
        str(p8) + str(d7) + str(d6) + str(d5) +
        str(p4) + str(d3) + str(p2) + str(p1)
    )

    print("Hamming code:", hamming_code)

if __name__ == "__main__":
    main()