def sender(data, i):
    print("Sender: Sending frame with data:", data[i])
    return data[i]

def receiver(frame):
    print("Receiver: Frame received:", frame)
    print("Receiver: Sending ACK")
    return True


def main():

    data = ["A", "B", "C", "D"]
    i = 0

    while i < len(data):

        # sender sends frame
        frame = sender(data, i)

        # receiver receives frame
        ack = receiver(frame)

        # sender receives ACK
        if ack:
            print("Sender: ACK received\n")
            i += 1


if __name__ == "__main__":
    main()