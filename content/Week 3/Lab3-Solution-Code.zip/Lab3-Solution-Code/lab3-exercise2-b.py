import sys

def check_binary_12bit(value):
    if len(value) != 12 or not set(value) <= {'0', '1'}:
        print("Error: input must be a 12-bit binary number.")
        sys.exit(1)

def main():
    code = input("Enter 12-bit Hamming code: ")
    check_binary_12bit(code)

    # extract bits from the 12-bit input
    d12 = int(code[0])
    d11 = int(code[1])
    d10 = int(code[2])
    d9  = int(code[3])
    p8  = int(code[4])
    d7  = int(code[5])
    d6  = int(code[6])
    d5  = int(code[7])
    p4  = int(code[8])
    d3  = int(code[9])
    p2  = int(code[10])
    p1  = int(code[11])

    # print all bits first
    print("d12 =", d12)
    print("d11 =", d11)
    print("d10 =", d10)
    print("d9 =", d9)
    print("p8 =", p8)
    print("d7 =", d7)
    print("d6 =", d6)
    print("d5 =", d5)
    print("p4 =", p4)
    print("d3 =", d3)
    print("p2 =", p2)
    print("p1 =", p1)

    # extract original 8-bit data 
    data = (
        str(d12) + str(d11) + str(d10) + str(d9) +
        str(d7) + str(d6) + str(d5) + str(d3)
    )

    print("Extracted data:", data)

    # compute parity bits again
    cp1 = d3 ^ d5 ^ d7 ^ d9 ^ d11
    cp2 = d3 ^ d6 ^ d7 ^ d10 ^ d11
    cp4 = d5 ^ d6 ^ d7 ^ d12
    cp8 = d9 ^ d10 ^ d11 ^ d12

    print("Computed parity bits:")
    print("p1 =", cp1)
    print("p2 =", cp2)
    print("p4 =", cp4)
    print("p8 =", cp8)

    # rebuild Hamming code
    computed_code = (
        str(d12) + str(d11) + str(d10) + str(d9) +
        str(cp8) + str(d7) + str(d6) + str(d5) +
        str(cp4) + str(d3) + str(cp2) + str(cp1)
    )

    print("Computed Hamming code:", computed_code)

    if code != computed_code:
        print("Error: the codeword has an error.")
    else:
        print("The codeword is correct.")

if __name__ == "__main__":
    main()