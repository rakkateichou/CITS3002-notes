import sys

def check_binary_8bit(value):
    if len(value) != 8 or not set(value) <= {'0','1'}:
        print("Error: input must be an 8-bit binary number.")
        sys.exit(1)

def main():
    val1 = input("Enter first 8-bit binary number: ")
    check_binary_8bit(val1)

    val2 = input("Enter second 8-bit binary number: ")
    check_binary_8bit(val2)

    a = int(val1, 2)
    b = int(val2, 2)

    distance = bin(a ^ b).count("1")

    print("Hamming distance:", distance)

if __name__ == "__main__":
    main()