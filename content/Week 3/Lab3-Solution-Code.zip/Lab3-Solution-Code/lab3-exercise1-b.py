import sys

def check_binary_8bit(value):
    if len(value) != 8 or not set(value) <= {'0','1'}:
        print("Error: input must be an 8-bit binary number.")
        sys.exit(1)

def main():
    codewords = []

    for i in range(4):
        val = input(f"Enter codeword {i+1} (8-bit binary number): ")
        check_binary_8bit(val)
        codewords.append(val)

    min_distance = 8

    for i in range(4):
        for j in range(i+1,4):
            a = int(codewords[i],2)
            b = int(codewords[j],2)

            distance = bin(a ^ b).count("1")

            if distance < min_distance:
                min_distance = distance

    print("Hamming distance of the code:", min_distance)

if __name__ == "__main__":
    main()