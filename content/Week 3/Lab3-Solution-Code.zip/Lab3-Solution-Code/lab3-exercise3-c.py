import random


def sender(data):
    print("Sender: Sending frame with data:", data)
    return data


def receiver(frame):
    print("Receiver: Frame received:", frame)
    print("Receiver: Sending ACK")
    return True


def main():

    data = ["A", "B", "C", "D"]
    
    for message in data:

        ack_received = False

        while not ack_received:

            frame = sender(message)

            # simulate frame loss (50%)
            if random.random() < 0.5:
                print("Channel: Frame lost")
                ack = None
            else:
                ack = receiver(frame)

            # simulate ACK loss (50%)
            if ack and random.random() < 0.5:
                print("Channel: ACK lost")
                ack = None

            if ack:
                print("Sender: ACK received\n")
                ack_received = True
            else:
                print("Sender: Timeout → Retransmitting frame\n")
             


if __name__ == "__main__":
    main()