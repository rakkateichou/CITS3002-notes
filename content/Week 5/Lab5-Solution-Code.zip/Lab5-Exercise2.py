# Dijkstra's algorithm from A to every other node
# This version is intentionally simple and shows the steps clearly

graph = {
    'A': {'B': 4, 'C': 2},
    'B': {'A': 4, 'C': 1, 'D': 5},
    'C': {'A': 2, 'B': 1, 'D': 8, 'E': 10},
    'D': {'B': 5, 'C': 8, 'E': 2, 'F': 6},
    'E': {'C': 10, 'D': 2, 'F': 3},
    'F': {'D': 6, 'E': 3}
}

source = 'A'

# Initial distances
dist = {}
previous = {}
permanent = []

for node in graph:
    dist[node] = float('inf')
    previous[node] = None

dist[source] = 0

step = 1

while len(permanent) < len(graph):
    # Choose the non-permanent node with the smallest tentative distance
    current = None
    min_distance = float('inf')

    for node in graph:
        if node not in permanent and dist[node] < min_distance:
            min_distance = dist[node]
            current = node

    # Make the selected node permanent
    permanent.append(current)

    print(f"\nStep {step}")
    print(f"Chosen node for next hop (made permanent): {current}")
    print("Permanent nodes:", permanent)

    # Update neighbors
    for neighbor in graph[current]:
        if neighbor not in permanent:
            new_distance = dist[current] + graph[current][neighbor]
            if new_distance < dist[neighbor]:
                dist[neighbor] = new_distance
                previous[neighbor] = current

    # Show tentative labels
    print("Tentative labels:")
    for node in graph:
        if node not in permanent:
            if dist[node] == float('inf'):
                print(f"  {node}: infinity")
            else:
                print(f"  {node}: {dist[node]} (via {previous[node]})")

    step += 1

# Function to reconstruct the path
def get_path(previous, destination):
    path = []
    current = destination

    while current is not None:
        path.append(current)
        current = previous[current]

    path.reverse()
    return path

# Final results
print("\nFinal shortest paths from A:")
for node in graph:
    path = get_path(previous, node)
    print(f"{source} -> {node}: path = {' -> '.join(path)}, cost = {dist[node]}")