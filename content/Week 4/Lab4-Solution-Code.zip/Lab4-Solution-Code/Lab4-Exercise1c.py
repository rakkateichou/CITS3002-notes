import math
import matplotlib.pyplot as plt

# --------- Functions ---------
def pure_aloha_throughput(G):
    return G * math.exp(-2 * G)

def slotted_aloha_throughput(G):
    return G * math.exp(-G)


# --------- Main ---------
def main():
    G_values = []
    pure_values = []
    slotted_values = []

    # Loop from 0.1 to 1.5
    G = 0.1
    while G <= 1.5:
        pure = pure_aloha_throughput(G)
        slotted = slotted_aloha_throughput(G)

        G_values.append(G)
        pure_values.append(pure)
        slotted_values.append(slotted)

        print(f"G = {G:.1f} | Pure = {pure:.5f} | Slotted = {slotted:.5f}")

        G += 0.1

    # --------- Plot ---------
    plt.figure()

    plt.plot(G_values, pure_values, marker='o', label='Pure ALOHA')
    plt.plot(G_values, slotted_values, marker='s', label='Slotted ALOHA')

    plt.xlabel("Offered Load (G)")
    plt.ylabel("Throughput (S)")
    plt.title("Throughput vs G (ALOHA Protocols)")

    plt.legend()
    plt.grid()

    plt.show()


# Run program
if __name__ == "__main__":
    main()