import random


def simulate_csma_cd():
    round_num = 1
    print("Initial collision occurs, so both terminals start binary exponential backoff.\n")

    while True:
        # Each terminal chooses a random backoff in [0, 2^i - 1]
        # capped at i = 10
        if round_num > 10:
            k_A = random.randint(0, (2 ** 10) - 1)
            k_B = random.randint(0, (2 ** 10) - 1)
        else:
            k_A = random.randint(0, (2 ** round_num) - 1)
            k_B = random.randint(0, (2 ** round_num) - 1)

        print(f"Round {round_num}:")
        print(f"Terminal A chooses backoff = {k_A}")
        print(f"Terminal B chooses backoff = {k_B}")

        if k_A == k_B:
            print("→ Both wait the same number of slots → collision occurs again.\n")
            round_num += 1

            if round_num > 16:
                print("Transmission failed after 16 attempts.")
                return
        else:
            if k_A < k_B:
                print(f"Terminal A waits {k_A} slot(s) and transmits first successfully.")
                print(f"Terminal B waits {k_B} slot(s) and then transmits successfully.\n")
            else:
                print(f"Terminal B waits {k_B} slot(s) and transmits first successfully.")
                print(f"Terminal A waits {k_A} slot(s) and then transmits successfully.\n")

            print("Final result:")
            print(f"Frames delivered after {round_num} retransmission(s).")
            return


simulate_csma_cd()