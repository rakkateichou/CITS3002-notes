import math

# --------- Functions ---------
def pure_aloha_throughput(G):
    return G * math.exp(-2 * G)

def slotted_aloha_throughput(G):
    return G * math.exp(-G)


# --------- Main ---------
def main():
    # Given parameters
    num_terminals = 10
    rate_per_terminal = 1       # frames/sec
    frame_time = 0.01           # 10 ms

    # Compute offered load G
    G = num_terminals * rate_per_terminal * frame_time

    # Compute throughput
    pure = pure_aloha_throughput(G)
    slotted = slotted_aloha_throughput(G)

    # Print results
    print(f"G = {G}")
    print(f"Pure ALOHA Throughput = {pure:.5f}")
    print(f"Slotted ALOHA Throughput = {slotted:.5f}")


# Run program
if __name__ == "__main__":
    main()